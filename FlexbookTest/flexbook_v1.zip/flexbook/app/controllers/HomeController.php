<?php
class HomeController
{
    public function home(){
        include "app/views/index.php";
    }
}