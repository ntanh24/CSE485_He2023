<?php
class UserRepository{
//    Định nghĩa các Hàm thao tác với CSDL: CRUD
//    UserRepository - User - CSDL


}